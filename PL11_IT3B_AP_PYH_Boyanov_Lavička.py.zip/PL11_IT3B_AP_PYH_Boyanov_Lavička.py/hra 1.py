import pygame
import math
import os
import random

pygame.init()
WIDTH, HEIGHT = 1280, 720
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("Moje Pygame Hra")

# Načtení obrázků
bg = pygame.image.load('bg.png')
mapa1 = pygame.image.load('mapa1.png')
bg_w, bg_h = bg.get_size()
char_sheet = pygame.image.load('Postavy/Character.png').convert_alpha()
skeleton_sheet = pygame.image.load('Postavy/Skeleton.png').convert_alpha()
heart_img = pygame.image.load('heart.png').convert_alpha()  # Obrázek srdíčka
lose_img = pygame.image.load('lose.png').convert_alpha()    # Obrázek pro prohru
frame_w, frame_h = 64, 64

# Obecná funkce pro načtení animací ze spritesheetu
def load_animation_frames(sheet, row, count):
    return [sheet.subsurface(pygame.Rect(i * frame_w, row * frame_h, frame_w, frame_h)) for i in range(count)]

walk = {
    "up": load_animation_frames(char_sheet, 8, 8),
    "left": load_animation_frames(char_sheet, 9, 8),
    "down": load_animation_frames(char_sheet, 10, 8),
    "right": load_animation_frames(char_sheet, 11, 8)
}

skeleton_walk = {
    "up": load_animation_frames(skeleton_sheet, 8, 8),
    "left": load_animation_frames(skeleton_sheet, 9, 8),
    "down": load_animation_frames(skeleton_sheet, 10, 8),
    "right": load_animation_frames(skeleton_sheet, 11, 8)
}

# Funkce pro načtení animací útoků
def load_attack_frames(direction):
    frames = []
    for i in range(6):
        path = f'utoky/{direction}h{i+1}.png'  # Předpokládáme, že soubory jsou v adresáři 'utoky/'
        if os.path.exists(path):  # Pokud soubor existuje, přidáme ho do seznamu
            frames.append(pygame.image.load(path).convert_alpha())
    return frames

# UI
font = pygame.font.SysFont(None, 36)
start_button = pygame.Rect(532, 380, 215, 80)
exit_button = pygame.Rect(532, 590, 215, 80)
settings_button = pygame.Rect(532, 500, 215, 80)

# Kolize
circle_collisions = [(560, 235, 70), (535, 280, 80), (515, 345, 35)]
rect_collisions = [pygame.Rect(725, 110, 135, 20), pygame.Rect(670, 120, 190, 20), pygame.Rect(850, 120, 15, 50),
                   pygame.Rect(865, 160, 10, 100), pygame.Rect(865, 200, 20, 100), pygame.Rect(880, 260, 20, 265),
                   pygame.Rect(500, 495, 380, 20), pygame.Rect(500, 520, 350, 20), pygame.Rect(500, 525, 200, 20),
                   pygame.Rect(490, 440, 20, 100), pygame.Rect(0, 0, bg_w, 10), pygame.Rect(0, bg_h - 10, bg_w, 10),
                   pygame.Rect(0, 0, 10, bg_h), pygame.Rect(bg_w - 10, 0, 10, bg_h)]

# Pomocné funkce
def circle_collides(hitbox, circle):
    cx, cy, r = circle
    closest_x = max(hitbox.left, min(cx, hitbox.right))
    closest_y = max(hitbox.top, min(cy, hitbox.bottom))
    return math.hypot(cx - closest_x, cy - closest_y) < r

def move_towards(src_x, src_y, dst_x, dst_y, speed):
    dx, dy = dst_x - src_x, dst_y - src_y
    dist = math.hypot(dx, dy)
    if dist != 0:
        dx, dy = dx / dist, dy / dist
    return src_x + dx * speed, src_y + dy * speed

# Inicializace
char_x, char_y = -1, -1
char_speed = 2
direction = "down"
is_moving = is_attacking = skeleton_alive = True
attack_index = anim_index = 0
attack_timer = anim_timer = 0
attack_delay = anim_delay = 100

# Přidáme hodnotu pro zpoždění animace skeletonů
skeleton_anim_delay = 120  # Toto je hodnota zpoždění animace skeletona (v milisekundách)

# Počáteční životy postavy
lives = 3

# Funkce pro zobrazení životů
def draw_lives():
    for i in range(lives):
        screen.blit(heart_img, (10 + i * 40, 10))

def check_collision(x, y):
    hitbox = pygame.Rect(x + 16, y + 40, 32, 20)
    # Zkontroluj kolizi s obdélníkovými kolizemi
    if any(hitbox.colliderect(r) for r in rect_collisions):
        return True
    # Zkontroluj kolizi s kruhovými kolizemi
    if any(circle_collides(hitbox, c) for c in circle_collisions):
        return True
    return False

# Inicializace skeletonů s kontrolou kolizí
skeletons = []

for _ in range(10):
    # Náhodné umístění skeletona
    x, y = random.randint(400, 1200), random.randint(100, 600)

    # Opakuj, dokud skeleton nebude umístěn na bezpečné pozici (bez kolize)
    while check_collision(x, y):
        x, y = random.randint(400, 1200), random.randint(100, 600)

    # Přidej skeletona do seznamu
    skeletons.append({
        'x': x,
        'y': y,
        'alive': True,
        'direction': "down",
        'anim_index': 0,
        'anim_timer': 0
    })

game_state = "menu"
clock = pygame.time.Clock()

# Herní smyčka
running = True
while running:
    dt = clock.tick(60)
    screen.fill((0, 0, 0))
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            running = False
        elif e.type == pygame.VIDEORESIZE:
            WIDTH, HEIGHT = e.w, e.h
            screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
        elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            if start_button.collidepoint(e.pos):
                if lives <= 0:  # Pokud má hráč 0 životů, resetuj hru
                    lives = 3  # Obnovit životy na 3
                    char_x, char_y = 100, 500  # Resetovat pozici postavy
                    skeletons.clear()  # Vymazat skeletony
                    for _ in range(10):  # Znovu přidat skeletony
                        x, y = random.randint(400, 1200), random.randint(100, 600)
                        while check_collision(x, y):
                            x, y = random.randint(400, 1200), random.randint(100, 600)
                        skeletons.append({
                            'x': x,
                            'y': y,
                            'alive': True,
                            'direction': "down",
                            'anim_index': 0,
                            'anim_timer': 0
                        })
                game_state = "mapa1"  # Nastavit stav hry na "mapa1"
            elif exit_button.collidepoint(e.pos): 
                running = False
            elif settings_button.collidepoint(e.pos): 
                game_state = "settings"

    keys = pygame.key.get_pressed()
    if keys[pygame.K_SPACE] and not is_attacking:
        is_attacking = True
        attack_index = attack_timer = 0

    x_offset = (WIDTH - bg_w) // 2
    y_offset = (HEIGHT - bg_h) // 2

    if game_state == "menu":
        screen.blit(bg, (x_offset, y_offset))
    elif game_state == "mapa1":
        screen.blit(mapa1, (x_offset, y_offset))
        if char_x == -1: char_x, char_y = 100, 500

        dx = dy = 0
        is_moving = False
        if not is_attacking:
            if keys[pygame.K_LEFT] or keys[pygame.K_a]: dx, direction, is_moving = -char_speed, "left", True
            if keys[pygame.K_RIGHT] or keys[pygame.K_d]: dx, direction, is_moving = char_speed, "right", True
            if keys[pygame.K_UP] or keys[pygame.K_w]: dy, direction, is_moving = -char_speed, "up", True
            if keys[pygame.K_DOWN] or keys[pygame.K_s]: dy, direction, is_moving = char_speed, "down", True
            if dx and dy: dx *= 0.7071; dy *= 0.7071

        hitbox = pygame.Rect(char_x + dx + 16, char_y + dy + 40, 32, 20)
        can_move = not any(hitbox.colliderect(r) for r in rect_collisions) and \
                   not any(circle_collides(hitbox, c) for c in circle_collisions)

        if can_move: char_x += dx; char_y += dy

        frame = walk[direction][0]
        if is_attacking:
           attack_frames = load_attack_frames(direction)
           if attack_frames:
               attack_timer += dt
               if attack_timer >= attack_delay:
                   attack_timer = 0
                   attack_index += 1
                   if attack_index >= len(attack_frames):
                       is_attacking = False
                       attack_index = 0
               if attack_index < len(attack_frames):
                   frame = attack_frames[attack_index]

                   # Zvětšení hitboxu meče podle směru útoku
                   if direction == "left" or direction == "right":
                       attack_rect = pygame.Rect(char_x + 16, char_y + 40, 125, 30)  # Širší hitbox pro útoky vlevo a vpravo
                   elif direction == "up" or direction == "down":
                       attack_rect = pygame.Rect(char_x + 16, char_y + 40, 30, 125)  # Vyšší hitbox pro útoky nahoru a dolů

                   for skeleton in skeletons:
                       skeleton_rect = pygame.Rect(skeleton['x'], skeleton['y'], frame_w , frame_h)
                       if attack_rect.colliderect(skeleton_rect): 
                           skeleton['alive'] = False


        elif is_moving:
            anim_timer += dt
            if anim_timer >= anim_delay:
                anim_timer = 0
                anim_index = (anim_index + 1) % len(walk[direction])
            frame = walk[direction][anim_index]

        screen.blit(frame, (x_offset + char_x, y_offset + char_y))

        # Vykreslení a pohyb skeletonů
        for skeleton in skeletons:
            if skeleton['alive']:
                # Výpočet směru skeletona
                dir_dx = char_x - skeleton['x']
                dir_dy = char_y - skeleton['y']
                if abs(dir_dx) > abs(dir_dy):
                    skeleton['direction'] = "right" if dir_dx > 0 else "left"
                else:
                    skeleton['direction'] = "down" if dir_dy > 0 else "up"       

                # Normovaný vektor pohybu
                dx, dy = dir_dx, dir_dy
                dist = math.hypot(dx, dy)
                if dist != 0:
                    dx /= dist
                    dy /= dist

                speed = 1
                moved = False

                # Pohyb skeletona
                try_x = skeleton['x'] + dx * speed
                try_y = skeleton['y'] + dy * speed
                hitbox = pygame.Rect(try_x + 16, try_y + 40, 24, 16)
                if not any(hitbox.colliderect(r) for r in rect_collisions) and \
                   not any(circle_collides(hitbox, c) for c in circle_collisions):
                    skeleton['x'], skeleton['y'] = try_x, try_y
                    moved = True
                
                # Zkontroluj kolizi mezi hráčem a skeletonem
                player_rect = pygame.Rect(char_x, char_y, frame_w, frame_h)
                if player_rect.colliderect(pygame.Rect(skeleton['x'], skeleton['y'], frame_w, frame_h)):
                    lives -= 1
                    skeleton['alive'] = False

                # Aktualizace animace skeletona
                skeleton['anim_timer'] += dt
                if skeleton['anim_timer'] >= skeleton_anim_delay:
                    skeleton['anim_timer'] = 0
                    skeleton['anim_index'] = (skeleton['anim_index'] + 1) % len(skeleton_walk[skeleton['direction']])

                skeleton_frame = skeleton_walk[skeleton['direction']][skeleton['anim_index']]
                screen.blit(skeleton_frame, (skeleton['x'], skeleton['y']))

        # Zobrazení životů
        draw_lives()

        # Pokud jsou životy 0, zobrazí se prohra
        if lives <= 0:
            screen.blit(lose_img, (WIDTH // 2 - lose_img.get_width() // 2, HEIGHT // 2 - lose_img.get_height() // 2))
            start_button = pygame.Rect(570, 455, 70, 70)
            exit_button = pygame.Rect(655, 455, 70, 70)

    pygame.display.flip()